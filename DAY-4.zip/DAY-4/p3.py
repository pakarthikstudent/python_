import sys

print('Test1')
print('Test2')
print('Test3')
try:
    print(Test)
except Exception:
    print(sys.exc_info())
    
print('Test5')
print('Test6')
for var in [1,2,3]:
    print('Test data')
print('End of the line')
