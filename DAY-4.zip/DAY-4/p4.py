import time
fobj = open('inventory.txt')
L = fobj.readlines()
fobj.close()

wobj = open('Inventory.log','w')
for var in L[2:]: # from 2nd index to all
    var=var.strip() # remove \n chars
    ItemCode,SalesCount = var.split(":")
    print('ItemCode    SalesCount')
    wobj.write('ItemCode   SalesCount\n')
    t=0
    for v in SalesCount.split(","):
        t=t+int(v)
    else:
        print(f'{ItemCode}\t\t{t}')
        print('-'*40)
        wobj.write(f'{ItemCode}\t\t{t}\n')
        wobj.write('-'*40+'\n')
else:
    wobj.write(f'Updated Date/time:{time.ctime()}\n')

wobj.close()
    
