import re

def my_findstr_grep():
    fobj = open('emp.csv','r')
    for var in fobj.readlines():
        var=var.strip() # remove \n chars
        if(re.search('sales',var,re.I)):
            print(var)
    fobj.close()

my_findstr_grep()
