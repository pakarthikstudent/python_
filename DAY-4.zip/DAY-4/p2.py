'''
read json data to python structure
'''
import json
import pprint

fobj = open('E:\\test1.json','r')
python_data = json.load(fobj)
fobj.close()
pprint.pprint(python_data)
