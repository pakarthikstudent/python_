'''
search multiple keywords(pattern) from inputfile
pattern1|pattern2 - any one pattern is matched ->OK
'''
import re

def my_findstr_grep():
    fobj = open('emp.csv','r')
    for var in fobj.readlines():
        var=var.strip() # remove \n chars
        if(re.search('sales|prod|DBA|Qa',var,re.I)):
            print(var)
    fobj.close()

my_findstr_grep()
