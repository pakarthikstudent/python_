'''
create a new json file and write python_struct to json
'''
import json

emp=[{'eid':101,'ename':'Raj','other_details':['sales','City1','A+']},
     {'eid':102,'ename':'Leo','other_details':['prod','City2','B+']},
     {'eid':103,'ename':'Anu','other_details':['HR','City3','O+']}]

wobj = open('E:\\test1.json','w')
json.dump(emp,wobj,indent=4)
wobj.close()
