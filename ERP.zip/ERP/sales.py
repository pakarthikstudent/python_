def f1():
	print('sales count:120')