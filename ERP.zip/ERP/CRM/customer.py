def display():
	print('Customer records')
