def FI():
	print('Invoice no:1242')