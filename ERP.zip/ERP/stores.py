def f3():
	print('list of files from stores dept')