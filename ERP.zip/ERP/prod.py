def f2():
	print('production details')