'''
REST - post
payload = {'key1': 'value1', 'key2': 'value2'}
response = requests.post(url, data=payload)
'''
import requests
import json

def update_hostname(device_ip, new_hostname, auth_token):
    url = f'http://{device_ip}/api/v1/configuration'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {auth_token}'
    }
    payload = {
        'hostname': new_hostname
    }

    response = requests.post(url, headers=headers, data=json.dumps(payload))

    if response.status_code == 200:
        print("Successfully updated the hostname.")
    else:
        print(f"Failed to update hostname. Status Code: {response.status_code}")

# Example usage
device_ip = '192.168.1.100'
new_hostname = 'NewRouterName'
auth_token = 'your_auth_token_here'

update_hostname(device_ip, new_hostname, auth_token)
