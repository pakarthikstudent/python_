def fx():
    print("This is p4.py file:",__name__)

if __name__ == '__main__':
    fx()
