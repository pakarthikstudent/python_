import requests
import json

r=request.get('https://www.google.com')

if(r.status_code != 200):
    print('URL download is failed')
    exit() # exit from python

if('text/html' in r.headers['Content-Type']):
    web_page = r.text
    wobj = open('Test.html','w')
    wobj.write(web_page)
    wobj.close()
elif('application/json' in r.headers['Content-Type']):
    jd = r.text
    pd = json.loads(jd) # convert from json to python
    # ....

