import requests
import json

def download_url(URL):
    r=requests.get(URL)
    if(r.status_code != 200):
        print('URL download is failed')
        exit() # exit from python
    if('text/html' in r.headers['Content-Type']):
        print('WebPage')
        web_page = r.text
        wobj = open('Test.html','w')
        wobj.write(web_page)
        wobj.close()
    elif('application/json' in r.headers['Content-Type']):
        print('Data Response')
        jd = r.text
        pd = json.loads(jd)
        print(type(pd))
