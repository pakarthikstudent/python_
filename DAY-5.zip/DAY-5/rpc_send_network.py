'''
send RPC command to network device
'''
import json
import requests

def get_switch_status(switch_ip, rpc_url, rpc_method):
    headers = {'Content-Type': 'application/json'}
    payload = {
        "jsonrpc": "2.0",
        "method": rpc_method,
        "params": [],
        "id": 1
    }

    response = requests.post(f'http://{switch_ip}/{rpc_url}', headers=headers, data=json.dumps(payload))

    if response.status_code == 200:
        return response.json()
    else:
        return f"Error: {response.status_code}"

# Example usage
switch_ip = '192.168.1.50'
rpc_url = 'rpc'
rpc_method = 'getSwitchStatus'

status = get_switch_status(switch_ip, rpc_url, rpc_method)
print(status)
