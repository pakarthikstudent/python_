def pin_test():
    wobj = open('pin_history.log','a')
    pin=1234
    c=0
    while(c<3):
        p = input('Enter a pin:')
        c=c+1
        if(int(p) == pin):
            wobj.write(f'Success - pin is matched {c}\n')
            print(f'Success - pin is matched {c}\n')
            break
        else:
            wobj.write(f'Failed - input pin {p} is not matched\n')
            
    if(int(p) != pin):
        wobj.write('Sorry your pin is blocked\n')
        print('Sorry your pin is blocked')
        
    wobj.close()

for var in [1,2,3]:
    pin_test()
