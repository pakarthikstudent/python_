class Enrollment:
    __Name = ''
    __DOB = ''
    __PLACE = ''
    def f1(self,n,d,p):
        self.__Name = n
        self.__DOB = d
        self.__PLACE = p
        print('Enrollment is done')
    def f2(self):
        print(f'''Emp name:{self.__Name}
        DOB:{self.__DOB} - Place:{self.__PLACE}''')

obj1 = Enrollment()
obj1.f1('arun','1st Jan','City-1') # f1(obj1,'arun','1st Jan','City-1')

obj2 = Enrollment()
obj2.f1('leo','2nd Feb','City-2')  # f1(obj2,'leo','2nd Feb','City-2')

obj1.f2()
obj2.f2()
