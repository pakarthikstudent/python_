class Enrollment:
    Name = ''
    DOB = ''

obj1 = Enrollment()
obj1.Name = 'arun'
obj1.DOB = '1st Jan'
print(f'Emp name is:{obj1.Name} DOB:{obj1.DOB}')

obj2 = Enrollment()
obj2.Name = 'leo'
obj2.DOB = '2nd Feb'
print(f'Emp name is:{obj2.Name} DOB:{obj2.DOB}')

Enrollment.PLACE=''
obj1.PLACE='City1'
obj2.PLACE='City2'
print(f'''{obj1.Name} working place is:{obj1.PLACE}
{obj2.Name} working place is:{obj2.PLACE}''')
      

