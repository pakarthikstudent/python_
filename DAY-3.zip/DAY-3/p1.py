
#employee
#  |-->empID,empName,emp_login,emp_pay

empID=123
empName='Raj'
emp_login=True
emp_pay=42335.23

# List - Collection of items => List_name = [ <list of items> ]

emp=[123,'Raj',True,42335.23] # list - mutable (we can add/modify/delete)
emp.append('sales')
emp.pop(2)
emp[-1]='prod'

Emp=(123,'Raj',True,42335.23) # tuple - immutable (we can't add/modify/delete)
Emp[0]
Emp[-2:]

ename = Emp[1] #OK

# dict - Collection of items(key:value) - mutable (we can add/modify/delete)

EMP={'eid':123,'ename':'Raj','ecost':42335.23}
print(EMP['eid'])
EMP['edept'] = 'sales' # dict_name['newKey'] = newValue
EMP['eplace'] = 'pune' # add new data to dict

EMP['edept']='prod' # modification
EMP.pop('ecost')  # remove


def f1():
    print(10+20)

f1() # simple function call

def f2(a,b):   # required arguments
    print(a+b)

f2(10,20) # function call with args
f2() # Error
f2(10) # Error

def f3(a=0,b=0): # default arguments
    print(a+b)

f3() # 0
f3(15) # 15
f3(15,25) # 40
def f4(a,b=0):
    print(a+b)
f4()  # Error
f4(5) # 5
f4(5,6) # 11

def f5(a=0,b=0):
    print(a+b)

f5() # OK
f5(10) # OK
f5(10,20) # OK
f5(10,20,30) # Error

def f6(*args):
    print(args)

f6() # OK
f6(10) # OK
f6(10,20) # OK
f6(10,20,30) #OK
f6(1,2,3,4,5,6,7,8) # OK
f6(a=10,b=20) # Error

def f7(**kwargs):
    print(kwargs)

f7() #OK
f7(a=10,b=20) #OK
f7(10,20) # Error

def fx(*args,**kwargs):
    pass
####################################

    python
      |
      Storage(File)

      file_obj = open('inputFile','r')
      file_obj.read() ->str  Vs file_obj.readlines() ->list
      file_obj.close()

      Create a new file ->write data to file
      =================   _____________________
       |                                 |__wobj.write('SingleString\n')
       \___ wobj = open('newFile','w')        -----(2)---
               (1)

               wobj.write(str(24343)+'\n')
               wobj.write('eid'+','+'ename'+'edept'+'\n')
               wobj.write(f'{eid},{ename},{edept}\n')
               wobj.close()






















