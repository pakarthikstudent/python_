import time
class vendor:
    def __init__(self,vID,vName,vGST):
        self.vID = vID
        self.vName = vName
        self.vGST = vGST
        print(f'Hello {vName} your enrollment is done')
    
    def billing(self,pName,pCost=0.0,pQty=0):
        self.pName = pName
        self.pCost = pCost
        self.pQty = pQty
        self.total = self.pCost * self.pQty
        self.tax = self.total * 0.18
        self.GS = self.total + self.tax
        
        wobj = open('products.log','a')
        s1=f'{self.vName}\t{self.vID}\t{self.vGST}\t{self.pName}\t{self.pCost}\t{self.pQty}\t{self.tax}'
        s2=f'{self.GS}\t {time.ctime()}\n'
        wobj.write(s1+s2)
        wobj.close()
        
vobj1 = vendor('V001','KLabs','GST1234')
vobj2 = vendor('V002','XYZ','GST994994')

vobj1.billing('prodA',1000,5)
vobj1.billing('prodB',1205,3)
vobj2.billing('prodC',1223,2)
vobj2.billing('prodB',500,7)

vobj3 = vendor('V003','Apex','GST93939')
vobj3.billing('prodX',4500,9)
