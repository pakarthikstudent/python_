class Enrollment:
    def __init__(self,n,d,p):
        self.__Name = n
        self.__DOB = d
        self.__PLACE = p
        print('Enrollment is done')
    def f2(self):
        print(f'''Emp name:{self.__Name}
        DOB:{self.__DOB} - Place:{self.__PLACE}''')

obj1 = Enrollment('arun','1st Jan','City-1')
obj2 = Enrollment('leo','2nd Feb','City-2')
obj1.f2()
obj2.f2()
