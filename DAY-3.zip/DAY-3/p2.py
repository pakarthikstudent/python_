import time
wobj = open('pin_history.log','a')
pin=1234
c=0
while(c<3):
	p = input('Enter a pin:')
	c=c+1
	if(int(p) == pin):
		wobj.write(f'Success - pin is matched {c} pin entry time:{time.ctime()}\n')
		print(f'Success - pin is matched {c}\n')
		break
	else:
		wobj.write(f'Failed - input pin {p} is not matched pin entry time:{time.ctime()}\n')

if(int(p) != pin):
	wobj.write('Sorry your pin is blocked-pin entry time:{time.ctime()}\n')
	print('Sorry your pin is blocked')
wobj.close()
