class Enrollment:
    Name = ''
    DOB = ''
    PLACE = ''
    def f1(self,n,d,p):
        self.Name = n
        self.DOB = d
        self.PLACE = p
        print('Enrollment is done')
    def f2(self):
        print(f'''Emp name:{self.Name}
        DOB:{self.DOB} - Place:{self.PLACE}''')

obj1 = Enrollment()
obj1.f1('arun','1st Jan','City-1')
print(obj1.Name) # arun
obj2 = Enrollment()
obj2.f1('leo','2nd Feb','City-2')

obj1.f2()
obj2.f2()
